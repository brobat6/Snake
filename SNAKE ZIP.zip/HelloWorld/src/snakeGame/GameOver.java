package snakeGame;

import java.awt.*;
import javax.swing.*;

public class GameOver extends JPanel {
	public GameOver() {
		setBackground(Color.white);
	}
}
